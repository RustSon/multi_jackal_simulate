^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package multi_jackal_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.5 (2018-02-19)
------------------

0.0.4 (2018-02-13)
------------------
* fixed launch file test
* Contributors: Nick Sullivan

0.0.3 (2018-02-13)
------------------
* licensing, URL's, tutorials updated
* Contributors: Nick Sullivan

0.0.2 (2018-02-12)
------------------

0.0.1 (2018-02-07)
------------------
* Contributors: Nick Sullivan
