^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package move_base_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.14.1 (2020-11-02)
-------------------
* Merge pull request `#19 <https://github.com/ros-planning/navigation_msgs/issues/19>`_ from ros-planning/recovery_behavior_msg
  Recovery behavior msg
* Contributors: David V. Lu, David V. Lu!!, Peter Mitrano

1.14.0 (2020-03-10)
-------------------
* Bump CMake version to avoid CMP0048
  Signed-off-by: Shane Loretz <sloretz@osrfoundation.org>
* Contributors: Shane Loretz

1.13.0 (2015-03-16)
-------------------
* initial release from new repository
* Contributors: Michael Ferguson
